require("dotenv").config();
const { google } = require("googleapis");
const { Client, GatewayIntentBits, EmbedBuilder } = require("discord.js");
const crypto = require("crypto");

const spreadsheetId = process.env.SPREADSHEET_ID;
const keyFile = process.env.GOOGLE_KEYFILE;

const token = process.env.DISCORD_TOKEN;
const salairesChannelId = process.env.SALAIRES_CHANNEL_ID;

function isSeparatorRow(row) {
  const first = row?.[0];
  return typeof first === "string" && first.trim().startsWith("|");
}

function round2(n) {
  if (typeof n !== "number") return n;
  return Math.round(n * 100) / 100;
}

function gradeRank(grade) {
  const order = ["Patron", "Co-Patron", "Contremaître", "Employé", "Apprenti"];
  const idx = order.indexOf(String(grade || ""));
  return idx === -1 ? 999 : idx;
}

function truthyLocked(v) {
  const s = String(v ?? "").trim().toLowerCase();
  return ["true", "vrai", "1", "yes", "oui", "lock", "locked"].includes(s);
}

function makeHash(obj) {
  return crypto.createHash("sha256").update(JSON.stringify(obj)).digest("hex");
}

function buildEmployeEmbed(weekKey, r) {
  const nom = r["Prénom et nom"] ?? "—";
  const grade = r["Grade"] ?? "—";

  const tele = r["Télégramme"] ?? "—";
  const prod = r["Quantité totale produite"] ?? "—";
  const salaire = round2(r["Salaire"]);
  const prime = round2(r["Prime"]);
  const rachat = round2(r["Total rachat"]);
  const totalPaye = round2(r["Total payé"]);
  const statut = r["Statut au moment de la clôture"] ?? "—";

  return new EmbedBuilder()
    .setTitle(`💰 ${weekKey} — ${grade} — ${nom}`)
    .setDescription(`**Statut :** ${statut}`)
    .addFields(
      { name: "Télégramme", value: String(tele), inline: true },
      { name: "Production", value: String(prod), inline: true },
      { name: "Total payé", value: String(totalPaye), inline: true },
      { name: "Salaire", value: String(salaire), inline: true },
      { name: "Prime", value: String(prime), inline: true },
      { name: "Rachat total", value: String(rachat), inline: true }
    )
    .setFooter({ text: "LGW | Menuiserie de Strawberry — Historique salaires" });
}

async function getSheetsClient() {
  const auth = new google.auth.GoogleAuth({
    keyFile,
    scopes: ["https://www.googleapis.com/auth/spreadsheets"], // on écrit dans BOT_STATE
  });
  return google.sheets({ version: "v4", auth });
}

async function readSalaires(sheets) {
  const sheetName = "Historique salaires";
  const range = `${sheetName}!A1:Z2000`;

  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range,
    valueRenderOption: "UNFORMATTED_VALUE",
  });

  const rows = res.data.values || [];
  const header = rows[0];
  const raw = rows.slice(1).filter((r) => !isSeparatorRow(r));

  return raw.map((r) => {
    const obj = {};
    for (let i = 0; i < header.length; i++) obj[header[i]] = r[i];
    return obj;
  });
}

async function readBotState(sheets) {
  const range = "BOT_STATE!A1:I2000";
  const res = await sheets.spreadsheets.values.get({ spreadsheetId, range });
  return res.data.values || [];
}

async function ensureBotStateHeader(sheets, existing) {
  const header = [
    "historique",
    "weekKey",
    "employeKey",
    "grade",
    "channelId",
    "messageId",
    "hash",
    "locked",
    "updatedAt",
  ];

  if (existing.length === 0) {
    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range: "BOT_STATE!A1:I1",
      valueInputOption: "RAW",
      requestBody: { values: [header] },
    });
    console.log("✅ BOT_STATE initialisé (en-têtes créés).");
    return header;
  }

  // si déjà présent, on suppose que la première ligne est l'en-tête
  return existing[0];
}

function buildStateMap(values) {
  // values: tableau complet BOT_STATE (incluant header)
  const map = new Map();
  for (let i = 1; i < values.length; i++) {
    const row = values[i];
    const historique = row[0];
    const weekKey = row[1];
    const employeKey = row[2];
    const key = `${historique}||${weekKey}||${employeKey}`;
    map.set(key, { rowIndex: i + 1, row }); // +1 car sheets index 1-based
  }
  return map;
}

async function upsertStateRow(sheets, existingRowIndexOrNull, rowValues) {
  if (existingRowIndexOrNull) {
    const range = `BOT_STATE!A${existingRowIndexOrNull}:I${existingRowIndexOrNull}`;
    await sheets.spreadsheets.values.update({
      spreadsheetId,
      range,
      valueInputOption: "RAW",
      requestBody: { values: [rowValues] },
    });
  } else {
    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: "BOT_STATE!A:I",
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      requestBody: { values: [rowValues] },
    });
  }
}

async function main() {
  if (!token) throw new Error("DISCORD_TOKEN manquant");
  if (!salairesChannelId) throw new Error("SALAIRES_CHANNEL_ID manquant dans .env");
  if (!spreadsheetId) throw new Error("SPREADSHEET_ID manquant");
  if (!keyFile) throw new Error("GOOGLE_KEYFILE manquant");

  const sheets = await getSheetsClient();

  // 1) Lire salaires
  const items = await readSalaires(sheets);
  const weeks = [...new Set(items.map((x) => x["Semaine"]).filter(Boolean))]
    .map(String)
    .sort();

  if (weeks.length === 0) {
    console.log("❌ Aucune semaine trouvée dans Historique salaires.");
    return;
  }

  const weekKey = process.argv[2] ? String(process.argv[2]) : weeks[weeks.length - 1];
  const weekRows = items.filter((x) => String(x["Semaine"]) === weekKey);

  // tri grade + nom
  weekRows.sort((a, b) => {
    const ga = gradeRank(a["Grade"]);
    const gb = gradeRank(b["Grade"]);
    if (ga !== gb) return ga - gb;
    return String(a["Prénom et nom"] || "").localeCompare(String(b["Prénom et nom"] || ""));
  });

  // 2) BOT_STATE: lire + header + map
  const stateValues = await readBotState(sheets);
  await ensureBotStateHeader(sheets, stateValues);

  const refreshedStateValues = await readBotState(sheets); // relit après init si vide
  const stateMap = buildStateMap(refreshedStateValues);

  // 3) Discord client
  const client = new Client({
    intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
  });

  client.once("ready", async () => {
    console.log(`✅ Discord connecté : ${client.user.tag}`);

    const channel = await client.channels.fetch(salairesChannelId);
    if (!channel) throw new Error("Channel salaires introuvable");

    let created = 0;
    let edited = 0;
    let skipped = 0;

    for (const r of weekRows) {
      const historique = "salaires";
      const employeKey = String(r["Prénom et nom"] || "").trim();
      const grade = String(r["Grade"] || "").trim();
      const stateKey = `${historique}||${weekKey}||${employeKey}`;

      // contenu “référence” pour hash (si ça change => edit)
      const signature = {
        weekKey,
        employeKey,
        grade,
        telegramme: r["Télégramme"],
        prod: r["Quantité totale produite"],
        salaire: round2(r["Salaire"]),
        prime: round2(r["Prime"]),
        rachat: round2(r["Total rachat"]),
        totalPaye: round2(r["Total payé"]),
        statut: r["Statut au moment de la clôture"],
      };
      const hash = makeHash(signature);

      const existing = stateMap.get(stateKey);
      const locked = existing ? truthyLocked(existing.row[7]) : false;

      if (locked) {
        skipped++;
        console.log(`⛔ LOCKED: ${weekKey} | ${employeKey}`);
        continue;
      }

      // Si hash identique => ne rien faire
      const oldHash = existing?.row?.[6];
      if (oldHash && oldHash === hash && existing?.row?.[5]) {
        skipped++;
        continue;
      }

      const embed = buildEmployeEmbed(weekKey, r);

      let messageId = existing?.row?.[5] || null;

      // si messageId existe, tenter edit
      if (messageId) {
        try {
          const msg = await channel.messages.fetch(messageId);
          await msg.edit({ embeds: [embed] });
          edited++;
        } catch (e) {
          // message supprimé / introuvable => on recrée
          const msg = await channel.send({ embeds: [embed] });
          messageId = msg.id;
          created++;
        }
      } else {
        const msg = await channel.send({ embeds: [embed] });
        messageId = msg.id;
        created++;
      }

      const now = new Date().toISOString();
      const rowValues = [
        historique,
        weekKey,
        employeKey,
        grade,
        String(salairesChannelId),
        String(messageId),
        hash,
        existing?.row?.[7] ?? "", // locked (on conserve)
        now,
      ];

      await upsertStateRow(sheets, existing?.rowIndex ?? null, rowValues);
    }

    console.log(`✅ Sync terminé — created: ${created}, edited: ${edited}, skipped: ${skipped}`);
    process.exit(0);
  });

  await client.login(token);
}

main().catch((err) => {
  console.error("❌", err?.message || err);
  if (err?.response?.data) console.error(err.response.data);
});
