require("dotenv").config();
const { REST, Routes, SlashCommandBuilder } = require("discord.js");

const clientId = process.env.CLIENT_ID;
const guildId = process.env.GUILD_ID;
const token = process.env.DISCORD_TOKEN;

if (!clientId || !guildId || !token) {
  console.error("❌ CLIENT_ID, GUILD_ID ou DISCORD_TOKEN manquant dans .env");
  process.exit(1);
}

const weekOption = (o) =>
  o
    .setName("semaine")
    .setDescription("Choisis une semaine (autocomplete)")
    .setRequired(true)
    .setAutocomplete(true);

const employeOption = (o) =>
  o
    .setName("employe")
    .setDescription("Choisis un employé (autocomplete)")
    .setRequired(true)
    .setAutocomplete(true);

const commands = [
  new SlashCommandBuilder()
    .setName("lock")
    .setDescription("Verrouille une semaine (salaires)")
    .addStringOption(weekOption),

  new SlashCommandBuilder()
    .setName("unlock")
    .setDescription("Déverrouille une semaine (salaires)")
    .addStringOption(weekOption),

  new SlashCommandBuilder()
    .setName("pay")
    .setDescription("Met un employé en Payé (salaires)")
    .addStringOption(weekOption)
    .addStringOption(employeOption),

  new SlashCommandBuilder()
    .setName("unpay")
    .setDescription("Met un employé en Pas payé (salaires)")
    .addStringOption(weekOption)
    .addStringOption(employeOption),

  new SlashCommandBuilder()
  .setName("payuser")
  .setDescription("Met un employé en Payé (salaires) via mention @user")
  .addStringOption(weekOption)
  .addUserOption(o => o.setName("user").setDescription("Utilisateur Discord").setRequired(true)),

new SlashCommandBuilder()
  .setName("unpayuser")
  .setDescription("Met un employé en Pas payé (salaires) via mention @user")
  .addStringOption(weekOption)
  .addUserOption(o => o.setName("user").setDescription("Utilisateur Discord").setRequired(true)),


  new SlashCommandBuilder()
    .setName("link")
    .setDescription("Admin: lier un compte Discord à un employé")
    .addUserOption((o) => o.setName("user").setDescription("Utilisateur Discord").setRequired(true))
    .addStringOption((o) => o.setName("nom").setDescription("Nom employé exact (ex: Jonah Crawford)").setRequired(true))
    .addStringOption((o) => o.setName("telegramme").setDescription("Télégramme (ex: 7163)").setRequired(false))
    .addBooleanOption((o) => o.setName("active").setDescription("Actif ? (par défaut true)").setRequired(false)),

  new SlashCommandBuilder()
    .setName("unlink")
    .setDescription("Admin: désactiver le lien (active=false) dans BOT_LINKS")
    .addUserOption((o) => o.setName("user").setDescription("Utilisateur Discord").setRequired(true)),

  new SlashCommandBuilder()
    .setName("dellink")
    .setDescription("Admin: SUPPRIMER la ligne BOT_LINKS d’un utilisateur")
    .addUserOption((o) => o.setName("user").setDescription("Utilisateur Discord").setRequired(true)),
].map((c) => c.toJSON());

const rest = new REST({ version: "10" }).setToken(token);

(async () => {
  try {
    console.log("⏳ Déploiement des slash commands...");
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), { body: commands });
    console.log("✅ Slash commands déployées sur le serveur.");
  } catch (err) {
    console.error("❌ Erreur deploy commands:", err);
  }
})();
