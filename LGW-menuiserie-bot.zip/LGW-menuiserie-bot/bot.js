require("dotenv").config();

const { Client, GatewayIntentBits, Events } = require("discord.js");
const { google } = require("googleapis");
const { execFile } = require("child_process");

const token = process.env.DISCORD_TOKEN;
const spreadsheetId = process.env.SPREADSHEET_ID;
const keyFile = process.env.GOOGLE_KEYFILE;

const payRoleIds = (process.env.PAY_ROLE_IDS || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);

const LINKS_SHEET = "BOT_LINKS";
const SALAIRES_SHEET = "Historique salaires";

if (!token || !spreadsheetId || !keyFile) {
  console.error("❌ .env incomplet: DISCORD_TOKEN / SPREADSHEET_ID / GOOGLE_KEYFILE requis");
  process.exit(1);
}
if (payRoleIds.length === 0) {
  console.warn("⚠️ PAY_ROLE_IDS est vide : aucune commande admin ne passera.");
}

function hasPayRole(member) {
  return payRoleIds.length > 0 && member?.roles?.cache?.some((r) => payRoleIds.includes(r.id));
}

function isSeparatorRow(row) {
  const first = row?.[0];
  return typeof first === "string" && first.trim().startsWith("|");
}

async function getSheets() {
  const auth = new google.auth.GoogleAuth({
    keyFile,
    scopes: ["https://www.googleapis.com/auth/spreadsheets"],
  });
  return google.sheets({ version: "v4", auth });
}

// ---------- BOT_STATE (lock) ----------

function isLockedValue(v) {
  const s = String(v ?? "").trim().toLowerCase();
  return ["true", "vrai", "1", "yes", "oui", "lock", "locked"].includes(s);
}

async function isWeekLocked(sheets, weekKey) {
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: "BOT_STATE!A1:I2000",
  });
  const rows = res.data.values || [];
  if (rows.length <= 1) return false;

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][1]) === String(weekKey)) return isLockedValue(rows[i][7]);
  }
  return false;
}

async function lockWeek(sheets, weekKey, lockedValue) {
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: "BOT_STATE!A1:I2000",
  });
  const rows = res.data.values || [];
  if (rows.length <= 1) return 0;

  let changed = 0;
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][1]) === String(weekKey)) {
      rows[i][7] = lockedValue ? "true" : "";
      changed++;
    }
  }

  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: `BOT_STATE!A1:I${rows.length}`,
    valueInputOption: "RAW",
    requestBody: { values: rows },
  });

  return changed;
}

// ---------- Historique salaires update ----------

function colLetterFromIndex(idx) {
  // OK tant que < 26 colonnes (A..Z)
  return String.fromCharCode("A".charCodeAt(0) + idx);
}

async function updateSalaireStatus(sheets, weekKey, employeName, newStatus) {
  const range = `${SALAIRES_SHEET}!A1:Z2000`;

  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range,
    valueRenderOption: "UNFORMATTED_VALUE",
  });

  const rows = res.data.values || [];
  if (rows.length < 2) throw new Error("Historique salaires vide.");

  const header = rows[0];
  const idxSemaine = header.indexOf("Semaine");
  const idxNom = header.indexOf("Prénom et nom");
  const idxStatut = header.indexOf("Statut au moment de la clôture");

  if (idxSemaine === -1 || idxNom === -1 || idxStatut === -1) {
    throw new Error("Colonnes introuvables dans Historique salaires.");
  }
  if (idxStatut >= 26) {
    throw new Error("Colonne statut au-delà de Z. Dis-moi et je gère AA/AB.");
  }

  let targetRowNumber = null;
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (isSeparatorRow(r)) continue;

    const sameWeek = String(r[idxSemaine]) === String(weekKey);
    const sameName =
      String(r[idxNom] || "").trim().toLowerCase() === String(employeName || "").trim().toLowerCase();

    if (sameWeek && sameName) {
      targetRowNumber = i + 1; // +1 car en-tête ligne 1
      break;
    }
  }

  if (!targetRowNumber) return false;

  const col = colLetterFromIndex(idxStatut);
  const writeRange = `${SALAIRES_SHEET}!${col}${targetRowNumber}`;

  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: writeRange,
    valueInputOption: "RAW",
    requestBody: { values: [[newStatus]] },
  });

  return true;
}

function runSyncSalaires(weekKey) {
  return new Promise((resolve, reject) => {
    execFile("node", ["sync-salaires-state.js", weekKey], { windowsHide: true }, (err, stdout, stderr) => {
      const out = `${stdout || ""}\n${stderr || ""}`.trim();
      if (err) return reject(out || err);
      resolve(out);
    });
  });
}

// ---------- BOT_LINKS ----------

async function ensureLinksSheetExists(sheets) {
  const meta = await sheets.spreadsheets.get({ spreadsheetId });
  const titles = (meta.data.sheets || []).map((s) => s.properties?.title);
  if (titles.includes(LINKS_SHEET)) return;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: { requests: [{ addSheet: { properties: { title: LINKS_SHEET } } }] },
  });

  await sheets.spreadsheets.values.update({
    spreadsheetId,
    range: `${LINKS_SHEET}!A1:E1`,
    valueInputOption: "RAW",
    requestBody: { values: [["telegramme", "employeName", "discordUserId", "active", "updatedAt"]] },
  });
}

async function readLinks(sheets) {
  await ensureLinksSheetExists(sheets);
  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `${LINKS_SHEET}!A1:E2000`,
  });
  return res.data.values || [];
}

async function upsertLink(sheets, { telegramme, employeName, discordUserId, active }) {
  const rows = await readLinks(sheets);
  const now = new Date().toISOString();
  const newRow = [telegramme || "", employeName || "", discordUserId, active ? "true" : "false", now];

  if (rows.length <= 1) {
    await sheets.spreadsheets.values.append({
      spreadsheetId,
      range: `${LINKS_SHEET}!A:E`,
      valueInputOption: "RAW",
      insertDataOption: "INSERT_ROWS",
      requestBody: { values: [newRow] },
    });
    return { action: "created" };
  }

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][2] || "") === String(discordUserId)) {
      const rowIndex = i + 1;
      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: `${LINKS_SHEET}!A${rowIndex}:E${rowIndex}`,
        valueInputOption: "RAW",
        requestBody: { values: [newRow] },
      });
      return { action: "updated" };
    }
  }

  await sheets.spreadsheets.values.append({
    spreadsheetId,
    range: `${LINKS_SHEET}!A:E`,
    valueInputOption: "RAW",
    insertDataOption: "INSERT_ROWS",
    requestBody: { values: [newRow] },
  });
  return { action: "created" };
}

async function deactivateLink(sheets, discordUserId) {
  const rows = await readLinks(sheets);
  if (rows.length <= 1) return { action: "not_found" };

  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][2] || "") === String(discordUserId)) {
      const rowIndex = i + 1;
      const now = new Date().toISOString();
      const updated = [rows[i][0] || "", rows[i][1] || "", String(discordUserId), "false", now];

      await sheets.spreadsheets.values.update({
        spreadsheetId,
        range: `${LINKS_SHEET}!A${rowIndex}:E${rowIndex}`,
        valueInputOption: "RAW",
        requestBody: { values: [updated] },
      });
      return { action: "disabled" };
    }
  }
  return { action: "not_found" };
}

async function deleteLinkRow(sheets, discordUserId) {
  await ensureLinksSheetExists(sheets);

  const meta = await sheets.spreadsheets.get({ spreadsheetId });
  const linkSheet = (meta.data.sheets || []).find((s) => s.properties?.title === LINKS_SHEET);
  if (!linkSheet) return { action: "not_found_sheet" };
  const sheetId = linkSheet.properties.sheetId;

  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `${LINKS_SHEET}!A1:E2000`,
  });
  const rows = res.data.values || [];
  if (rows.length <= 1) return { action: "not_found" };

  let rowIndex1Based = null;
  for (let i = 1; i < rows.length; i++) {
    if (String(rows[i][2] || "") === String(discordUserId)) {
      rowIndex1Based = i + 1;
      break;
    }
  }
  if (!rowIndex1Based) return { action: "not_found" };

  const startIndex = rowIndex1Based - 1; // 0-based
  const endIndex = startIndex + 1;

  await sheets.spreadsheets.batchUpdate({
    spreadsheetId,
    requestBody: {
      requests: [
        {
          deleteDimension: {
            range: { sheetId, dimension: "ROWS", startIndex, endIndex },
          },
        },
      ],
    },
  });

  return { action: "deleted" };
}

async function getEmployeNameByDiscordId(sheets, discordUserId) {
  const rows = await readLinks(sheets);
  for (let i = 1; i < rows.length; i++) {
    const userId = rows[i][2];
    const active = String(rows[i][3] || "").toLowerCase();
    const employeName = rows[i][1];

    if (String(userId) === String(discordUserId) && active === "true" && employeName) {
      return String(employeName);
    }
  }
  return null;
}

// ---------- AUTOCOMPLETE ----------

const cache = {
  weeks: { ts: 0, data: [] },
  employeesByWeek: new Map(), // weekKey -> { ts, data }
};

function filterChoices(list, focused) {
  const q = String(focused || "").toLowerCase();
  const filtered = q ? list.filter((x) => String(x).toLowerCase().includes(q)) : list.slice(0);
  return filtered.slice(0, 25).map((x) => ({ name: String(x), value: String(x) }));
}

async function getWeeks(sheets) {
  const now = Date.now();
  if (now - cache.weeks.ts < 60_000 && cache.weeks.data.length) return cache.weeks.data;

  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `${SALAIRES_SHEET}!A1:A2000`,
    valueRenderOption: "UNFORMATTED_VALUE",
  });

  const col = (res.data.values || []).flat().map(String);
  const weeks = [...new Set(col.filter((v) => v && v !== "Semaine" && !v.startsWith("|")))].sort();

  cache.weeks = { ts: now, data: weeks };
  return weeks;
}

async function getEmployeesForWeek(sheets, weekKey) {
  const now = Date.now();
  const cached = cache.employeesByWeek.get(weekKey);
  if (cached && now - cached.ts < 60_000) return cached.data;

  const res = await sheets.spreadsheets.values.get({
    spreadsheetId,
    range: `${SALAIRES_SHEET}!A1:Z2000`,
    valueRenderOption: "UNFORMATTED_VALUE",
  });

  const rows = res.data.values || [];
  if (rows.length < 2) return [];

  const header = rows[0];
  const idxWeek = header.indexOf("Semaine");
  const idxName = header.indexOf("Prénom et nom");
  if (idxWeek === -1 || idxName === -1) return [];

  const names = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (isSeparatorRow(r)) continue;
    if (String(r[idxWeek]) === String(weekKey) && r[idxName]) names.push(String(r[idxName]));
  }

  const unique = [...new Set(names)].sort();
  cache.employeesByWeek.set(weekKey, { ts: now, data: unique });
  return unique;
}

// ---------- Discord client ----------

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.once(Events.ClientReady, () => {
  console.log(`✅ Bot prêt : ${client.user.tag}`);
});

// Autocomplete
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isAutocomplete()) return;

  try {
    const sheets = await getSheets();
    const focused = interaction.options.getFocused(true);

    if (focused.name === "semaine") {
      const weeks = await getWeeks(sheets);
      return interaction.respond(filterChoices(weeks, focused.value));
    }

    if (focused.name === "employe") {
      const weekKey = interaction.options.getString("semaine");
      if (!weekKey) return interaction.respond([]);
      const emps = await getEmployeesForWeek(sheets, weekKey);
      return interaction.respond(filterChoices(emps, focused.value));
    }

    return interaction.respond([]);
  } catch (e) {
    console.error("Autocomplete error:", e);
    try {
      await interaction.respond([]);
    } catch {}
  }
});

// Commands
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  const adminCommands = new Set([
    "lock",
    "unlock",
    "pay",
    "unpay",
    "payuser",
    "unpayuser",
    "link",
    "unlink",
    "dellink",
  ]);

  try {
    const cmd = interaction.commandName;
    const sheets = await getSheets();

    if (adminCommands.has(cmd) && !hasPayRole(interaction.member)) {
      return interaction.reply({ content: "⛔ Tu n’as pas la permission.", ephemeral: true });
    }

    // /link
    if (cmd === "link") {
      await interaction.deferReply({ ephemeral: true });

      const user = interaction.options.getUser("user");
      const employeName = interaction.options.getString("nom");
      const telegramme = interaction.options.getString("telegramme") || "";
      const active = interaction.options.getBoolean("active");
      const isActive = active === null ? true : active;

      const result = await upsertLink(sheets, {
        telegramme,
        employeName,
        discordUserId: user.id,
        active: isActive,
      });

      return interaction.editReply(
        `✅ Lien ${result.action}.\nDiscord: <@${user.id}>\nEmployé: **${employeName}**\nTélégramme: **${telegramme || "—"}**\nActif: **${
          isActive ? "true" : "false"
        }**`
      );
    }

    // /unlink (désactive)
    if (cmd === "unlink") {
      await interaction.deferReply({ ephemeral: true });
      const user = interaction.options.getUser("user");
      const result = await deactivateLink(sheets, user.id);

      return interaction.editReply(
        result.action === "disabled"
          ? `✅ Lien désactivé pour <@${user.id}>.`
          : `⚠️ Aucun lien trouvé pour <@${user.id}>.`
      );
    }

    // /dellink (supprime ligne)
    if (cmd === "dellink") {
      await interaction.deferReply({ ephemeral: true });
      const user = interaction.options.getUser("user");
      const result = await deleteLinkRow(sheets, user.id);

      if (result.action === "deleted") return interaction.editReply(`🗑️ Ligne supprimée dans BOT_LINKS pour <@${user.id}>.`);
      if (result.action === "not_found") return interaction.editReply(`⚠️ Aucune ligne BOT_LINKS trouvée pour <@${user.id}>.`);
      return interaction.editReply("⚠️ Impossible de supprimer (onglet BOT_LINKS introuvable).");
    }

    // /lock /unlock
    if (cmd === "lock" || cmd === "unlock") {
      await interaction.deferReply({ ephemeral: true });
      const semaine = interaction.options.getString("semaine");
      const changed = await lockWeek(sheets, semaine, cmd === "lock");

      return interaction.editReply(
        cmd === "lock"
          ? `✅ Semaine **${semaine}** verrouillée (${changed} lignes).`
          : `✅ Semaine **${semaine}** déverrouillée (${changed} lignes).`
      );
    }

    // /pay /unpay (week + employe autocomplete)
    if (cmd === "pay" || cmd === "unpay") {
      await interaction.deferReply({ ephemeral: true });

      const semaine = interaction.options.getString("semaine");
      const employe = interaction.options.getString("employe");
      const newStatus = cmd === "pay" ? "Payé" : "Pas payé";

      const locked = await isWeekLocked(sheets, semaine);
      if (locked) return interaction.editReply(`⛔ La semaine **${semaine}** est verrouillée.`);

      const ok = await updateSalaireStatus(sheets, semaine, employe, newStatus);
      if (!ok) return interaction.editReply(`❌ Employé introuvable pour **${semaine}** : "${employe}"`);

      let out;
      try {
        out = await runSyncSalaires(semaine);
      } catch (syncErr) {
        return interaction.editReply(
          `✅ Statut mis à jour: **${employe}** → **${newStatus}**.\n❌ Sync Discord échouée :\n\`\`\`\n${String(syncErr).slice(
            -900
          )}\n\`\`\``
        );
      }

      return interaction.editReply(
        `✅ Statut mis à jour: **${employe}** → **${newStatus}**.\n🧾 Résultat sync:\n\`\`\`\n${String(out).slice(-900)}\n\`\`\``
      );
    }

    // /payuser /unpayuser (week autocomplete + mention @user)
    if (cmd === "payuser" || cmd === "unpayuser") {
      await interaction.deferReply({ ephemeral: true });

      const semaine = interaction.options.getString("semaine");
      const user = interaction.options.getUser("user");
      const newStatus = cmd === "payuser" ? "Payé" : "Pas payé";

      const locked = await isWeekLocked(sheets, semaine);
      if (locked) return interaction.editReply(`⛔ La semaine **${semaine}** est verrouillée.`);

      const employeName = await getEmployeNameByDiscordId(sheets, user.id);
      if (!employeName) {
        return interaction.editReply(
          `❌ Aucun lien actif trouvé pour <@${user.id}> dans **BOT_LINKS**.\n👉 Fais d’abord: \`/link user:@... nom:"Prénom Nom"\``
        );
      }

      const ok = await updateSalaireStatus(sheets, semaine, employeName, newStatus);
      if (!ok) {
        return interaction.editReply(`❌ Employé introuvable dans Historique salaires pour **${semaine}** : "${employeName}"`);
      }

      let out;
      try {
        out = await runSyncSalaires(semaine);
      } catch (syncErr) {
        return interaction.editReply(
          `✅ Statut mis à jour: **${employeName}** → **${newStatus}**.\n❌ Sync Discord échouée :\n\`\`\`\n${String(syncErr).slice(
            -900
          )}\n\`\`\``
        );
      }

      return interaction.editReply(
        `✅ <@${user.id}> (**${employeName}**) → **${newStatus}**.\n🧾 Résultat sync:\n\`\`\`\n${String(out).slice(-900)}\n\`\`\``
      );
    }

    return interaction.reply({ content: "❓ Commande non gérée.", ephemeral: true });
  } catch (e) {
    console.error(e);
    if (interaction.deferred || interaction.replied) {
      return interaction.editReply({ content: `❌ Erreur: ${e?.message || e}` });
    }
    return interaction.reply({ content: `❌ Erreur: ${e?.message || e}`, ephemeral: true });
  }
});

client.login(token);
